<!-- Standalone pages also use this fragment without a document head. -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
  /* Self-hosted Vazirmatn variable font (reliable on the Iran network, no external CDN) */
  @font-face {
    font-family: 'Vazirmatn';
    src: url('/webfont/Vazirmatn[wght].woff2') format('woff2-variations'),
         url('/webfont/Vazirmatn[wght].woff2') format('woff2');
    font-weight: 100 900;
    font-style: normal;
    font-display: swap;
  } 
  body {
    font-family: 'Vazirmatn', sans-serif !important;
    overflow-x: hidden;
  }
    :root{
      --cta-orange:#faa61a;
      --cta-orange-2:#e99508;
      --cta-text:#ffffff;
      --cta-muted: rgba(255,255,255,.78);
      --cta-container: 1440px;
      --cta-nav-h: 78px;

      --cta-shadow: 0 10px 22px rgba(0,0,0,.14);
      --cta-shadow-soft: 0 8px 18px rgba(0,0,0,.12);
      --cta-radius: 14px;
      --cta-edge-gap: 10px;
    }

    .cta {
      font-family: inherit;
      direction: rtl;
      position: relative;
    }
    .cta a{ color:inherit; text-decoration:none; }
    .cta button, .cta input{ font-family: inherit; }

    .cta-container{
    width: min(var(--cta-container), 100%);
    margin-inline:auto;
    padding-inline:16px;
    }

    /* ===== TOP BAR ===== */
    .cta-topbar{
      position:fixed;
      top:0; left:0; right:0;
      height: var(--cta-nav-h);
      z-index:99999;
      display:flex;
      align-items:center;
      overflow-x: clip;
      overflow-y: visible;
      padding-inline: 0;
      background: var(--cta-orange);
      box-shadow: 0 4px 24px -2px rgba(0,0,0,0.14);
      transition: transform 0.3s cubic-bezier(0.16, 1, 0.3, 1), top 0.3s ease, height 0.3s ease;
    }

    /* Detached look when scrolled */
    .cta-topbar.scrolled {
      top: 0;
      height: 68px;
    }

    /* فاصله‌گذار هم‌ارتفاع نوار ثابت تا محتوای صفحه زیر آن پنهان نشود */
    .cta-navbar-spacer {
      height: var(--cta-nav-h);
    }

    .cta-header{
      display:flex;
      align-items:center;
      justify-content:space-between;
      gap:10px;
      position: relative;
      z-index: 60;
      background: transparent;
      border: none;
      border-radius: 0;
      box-shadow: none;
      padding: 0 16px;
      height: 100%;
      width: 100%;
    }

    /* راست: لوگو با صفحه شیشه‌ای مات که از زیر قسمت زرد هدر بیرون زده */
    .cta-right{
      display:flex;
      align-items:center;
      flex:0 0 auto;
      align-self: stretch;
      position: relative;
      margin-right: calc(-1 * var(--cta-edge-gap));
      padding-right: calc(var(--cta-edge-gap) + 12px);
      padding-left: 64px;
      z-index: 5;
    }

    /* صفحه شیشه‌ای مات (Frosted Glass) با امتداد تا لبه راست صفحه و برش مورب در محل ورود */
    .cta-glass-underlay {
      position: absolute;
      top: 0;
      bottom: 0;
      left: 0;
      right: -100vw;
      background: rgba(255, 255, 255, 0.76);
      -webkit-backdrop-filter: blur(28px) saturate(190%) contrast(105%);
      backdrop-filter: blur(28px) saturate(190%) contrast(105%);
      clip-path: polygon(26px 0, 100% 0, 100% 100%, 0 100%);
      pointer-events: none;
      z-index: -1;
      border-bottom: 1px solid rgba(255, 255, 255, 0.45);
      box-shadow: inset 0 1.5px 2px rgba(255, 255, 255, 0.95);
    }

    /* سایه نرم و عمق‌دار لایه زرد رنگ روی صفحه شیشه زیرین (حس دقیق لایه رو و لایه زیر) */
    .cta-glass-underlay::before {
      content: "";
      position: absolute;
      top: 0;
      bottom: 0;
      left: 0;
      width: 38px;
      background: linear-gradient(to left, transparent 0%, rgba(0, 0, 0, 0.08) 40%, rgba(0, 0, 0, 0.28) 100%);
      clip-path: polygon(26px 0, 38px 0, 12px 100%, 0 100%);
      z-index: 2;
      pointer-events: none;
    }

    /* لبه نوری براق (Bevel Highlight) روی مرز برش مورب زرد */
    .cta-glass-underlay::after {
      content: "";
      position: absolute;
      top: 0;
      bottom: 0;
      left: 0;
      width: 28px;
      background: linear-gradient(180deg, rgba(255,255,255,0.85) 0%, rgba(255,255,255,0.4) 100%);
      clip-path: polygon(24.5px 0, 26px 0, 1.5px 100%, 0 100%);
      z-index: 3;
      pointer-events: none;
    }

    .cta-brand{
      display:inline-flex;
      align-items:center;
      justify-content:center;
      position: relative;
      z-index: 4;
      text-decoration:none;
      transition: transform 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
    }

    .cta-brand:hover{
      transform: scale(1.04);
    }

    .cta-brand:active{
      transform: scale(0.96);
    }

    .cta-brand img{
      height: 38px;
      width: auto;
      display:block;
      object-fit: contain;
      filter: drop-shadow(0 1px 3px rgba(0, 0, 0, 0.1));
    }

    /* وسط: منو */
    .cta-center{
      display:flex;
      justify-content:center;
      flex:1 1 auto;
      min-width: 0;
      padding-inline: 8px;
    }

    /* باکس دور منو مثل سرچ/ثبت‌نام */
    .cta-navbox{
      background: transparent;
      border: none;
      padding: 6px 14px;
    }

    .cta-glass {
      /* Removed glass effect */
    }

    /* منو افقی (حل عمودی شدن) */
    .cta-menu{
      list-style: none;
      margin: 0;
      padding: 0;
      display:flex;
      align-items:center;
      gap: 6px;
      white-space: nowrap;
      flex-wrap: nowrap;
    }

    .cta-menu > li{
      position: relative;
      display:flex;
      align-items:center;
    }

    .cta-menu > li > a{
      display:inline-flex;
      align-items:center;
      padding:8px 10px;
      border-radius:10px;
      transition: .2s ease;
      outline: none;
      font-size: 14px;
      font-weight: 700;
      color: #111111;
    }

    .cta-menu > li > a:hover{
      background: rgba(0,0,0,.06);
    }

    .cta-menu > li > a:focus-visible{
      box-shadow: 0 0 0 3px rgba(0,0,0,.15);
      background: rgba(0,0,0,.06);
    }

    .highlighted-menu > a{
      background: rgba(250, 166, 26,.18);
      border: 1px solid rgba(250, 166, 26,.35);
    }
    .highlighted-menu > a:hover{
      background: rgba(250, 166, 26,.26);
    }

    /* چپ: سرچ + ورود/ثبت‌نام */
    .cta-left{
      display:flex;
      align-items:center;
      gap:10px;
      flex:0 0 auto;
      margin-left: calc(-1 * var(--cta-edge-gap)); /* نزدیک‌تر به لبه */
      padding-left: var(--cta-edge-gap);
    }

    .cta-donate {
      height: 38px;
      border-radius: 10px;
      border: none;
      background: linear-gradient(135deg, #e53935, #c62828);
      color: #ffffff !important;
      padding: 0 16px;
      cursor: pointer;
      transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1);
      display: inline-flex;
      align-items: center;
      gap: 8px;
      white-space: nowrap;
      font-weight: 800;
      box-shadow: 0 4px 12px rgba(198, 40, 40, 0.3);
    }

    .cta-donate:hover {
      transform: translateY(-2px);
      box-shadow: 0 6px 16px rgba(198, 40, 40, 0.4);
      background: linear-gradient(135deg, #c62828, #b71c1c);
    }

    .cta-donate:active {
      transform: translateY(1px);
      box-shadow: 0 2px 8px rgba(198, 40, 40, 0.2);
    }

    .cta-auth {
      height: 38px;
      border-radius: 10px;
      border: 1px solid rgba(0, 143, 138, 0.4);
      background: linear-gradient(135deg, #008f8a, #00736f);
      color: #ffffff !important;
      padding: 0 16px;
      cursor: pointer;
      transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1);
      display: inline-flex;
      align-items: center;
      gap: 8px;
      white-space: nowrap;
      font-weight: 700;
      box-shadow: 0 0 12px rgba(0, 143, 138, 0.3);
      text-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
    }

    .cta-auth:hover {
      transform: translateY(-2px);
      box-shadow: 0 0 20px rgba(0, 143, 138, 0.6);
      background: linear-gradient(135deg, #05a8a2, #008f8a);
    }

    .cta-auth:active {
      transform: translateY(1px);
      box-shadow: 0 0 8px rgba(0, 143, 138, 0.4);
    }

    /* ===== Mega Menu ===== */
    .mega-menu{
      position: relative;
    }

    /* مگا منو با عرض کامل صفحه */
    .mega-menu .mega-menu-content {
      display: block;
      opacity: 0;
      visibility: hidden;
      transform: translateY(16px) scale(0.98);
      transform-origin: top center;
      transition:
        opacity 0.25s cubic-bezier(0.4, 0, 0.2, 1),
        transform 0.25s cubic-bezier(0.4, 0, 0.2, 1),
        visibility 0.25s;
      position: fixed;
      top: calc(var(--cta-nav-h) + 10px);
      right: 16px;
      left: 16px;
      max-width: var(--cta-container);
      margin-inline: auto;
      background: rgba(0, 143, 138, 0.88); /* Translucent premium teal glass */
      backdrop-filter: blur(20px) saturate(140%);
      -webkit-backdrop-filter: blur(20px) saturate(140%);
      border: 1px solid rgba(255, 255, 255, 0.15);
      padding: 28px 20px;
      box-shadow:
        0 20px 40px rgba(0, 0, 0, 0.4),
        inset 0 1px 0 rgba(255, 255, 255, 0.2);
      z-index: 9999;
      direction: rtl;
      text-align: right;
      border-radius: 16px;
      overflow: hidden;
      box-sizing: border-box;
    }

    /* باز شدن مگا منو */
    .mega-menu.open .mega-menu-content {
      opacity: 1;
      visibility: visible;
      transform: translateY(0) scale(1);
    }

    /* ساختار ردیف و چهار ستون */
    .mega-menu-content .mega-row {
      display: grid;
      grid-template-columns: repeat(4, 1fr); /* چهار ستون در یک ردیف */
      gap: 20px; /* فاصله بین ستون‌ها */
      width: 100%; /* عرض کامل صفحه */
    }

    /* هر ستون (مگا کال) */
    .mega-menu-content .mega-col {
      padding: 0 16px;
      border-left: 1px solid rgba(255,255,255,0.55);
    }

    /* حذف مرز از آخرین ستون */
    .mega-menu-content .mega-col:last-child {
      border-left: none;
    }

    /* استایل متن‌ها */
    .mega-menu-content h6,
    .mega-menu-content .mega-col-title {
      font-weight: bold;
      margin: 0 0 12px 0;
      color: #fff;
      font-size: 15px;
    }

    .mega-menu-content a {
      display: block;
      color: #f9f9f9;
      font-size: 14px;
      margin-bottom: 10px;
      transition: all .25s ease;
    }

    .mega-menu-content a:hover {
      color: #FFD700;
      padding-right: 5px;
    }

    @media (max-width: 1200px){
      .mega-menu-content .mega-row{
        grid-template-columns: repeat(3, minmax(0, 1fr));
      }
    }

    @media (max-width: 980px){
      .mega-menu-content .mega-row{
        grid-template-columns: repeat(2, minmax(0, 1fr));
      }
    }

    @media (max-width: 768px){
      .mega-menu .mega-menu-content{
        padding: 20px;
      }
      .mega-menu-content .mega-row{
        grid-template-columns: 1fr;
        gap: 16px;
      }
      .mega-menu-content .mega-col{
        border-left: none;
        padding: 0;
      }
    }

    @media (max-width: 480px){
      .mega-menu-content{
        right: 12px;
        left: 12px;
      }
      .mega-menu-content .mega-col h6{
        font-size: 13px;
      }
      .mega-menu-content a{
        font-size: 13px;
      }
    }

    /* ===== HAMBURGER ICON ===== */
    .menu-icon{
      width: 38px;
      height: 38px;
      display: none;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      gap: 5px;
      cursor: pointer;
      border-radius: 10px;
      background: rgba(255,255,255,.08);
      border: 1px solid rgba(255,255,255,.14);
      transition: background .2s ease, border-color .2s ease;
    }

    .menu-icon:hover{
      background: rgba(255,255,255,.14);
      border-color: rgba(255,255,255,.22);
    }

    .menu-icon div{
      width: 17px;
      height: 2px;
      background: #fff;
      border-radius: 2px;
      transition: opacity .3s ease;
    }

    /* فقط موبایل و تبلت */
    @media (max-width: 1399px){
      .menu-icon{ display:flex; }
    }

    /* ===== MOBILE MENU REDESIGN ===== */
    .mobile-menu-sidebar {
      position: fixed;
      top: 0;
      right: -100%;
      width: min(340px, 88vw);
      height: 100%;
      height: 100vh;
      height: 100dvh;
      max-height: 100dvh;
      background: rgba(255, 255, 255, 0.98);
      backdrop-filter: blur(24px) saturate(180%);
      -webkit-backdrop-filter: blur(24px) saturate(180%);
      border-left: 1px solid rgba(250, 166, 26, 0.25);
      box-shadow: -12px 0 36px rgba(0, 0, 0, 0.15);
      z-index: 200000;
      display: flex;
      flex-direction: column;
      padding: 0;
      overflow-y: auto;
      overscroll-behavior: contain;
      -webkit-overflow-scrolling: touch;
      touch-action: pan-y;
      visibility: hidden;
      transition: right 0.38s cubic-bezier(0.16, 1, 0.3, 1), visibility 0.38s;
      direction: rtl;
    }

    .mobile-menu-sidebar.open {
      right: 0;
      visibility: visible;
    }

    body.mobile-menu-open {
      overflow: hidden !important;
      touch-action: none;
    }

    /* Drawer Header - Sticky at top of drawer when scrolling */
    .mobile-menu-header {
      position: sticky;
      top: 0;
      z-index: 20;
      display: flex;
      align-items: center;
      justify-content: space-between;
      height: var(--cta-nav-h, 56px);
      min-height: 56px;
      padding: 0 16px;
      background: rgba(255, 255, 255, 0.96);
      backdrop-filter: blur(16px);
      -webkit-backdrop-filter: blur(16px);
      border-bottom: 1px solid rgba(0, 0, 0, 0.07);
      flex-shrink: 0;
      box-sizing: border-box;
    }

    .mobile-menu-brand {
      display: flex;
      align-items: center;
    }

    .mobile-menu-brand img {
      height: 32px;
      width: auto;
      object-fit: contain;
    }

    .mobile-menu-close {
      width: 36px;
      height: 36px;
      border-radius: 50%;
      background: #f1f5f9;
      border: 1px solid rgba(0, 0, 0, 0.06);
      color: #475569;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      transition: all 0.2s ease;
      outline: none;
      padding: 0;
    }

    .mobile-menu-close:hover {
      background: #e2e8f0;
      color: #0f172a;
      transform: scale(1.05);
    }

    .mobile-menu-close:active {
      transform: scale(0.95);
    }

    /* Drawer Action Bar */
    .mobile-menu-actions {
      display: flex;
      gap: 10px;
      padding: 14px 18px 8px 18px;
      flex-shrink: 0;
    }

    .mobile-action-donate {
      flex: 1;
      height: 42px;
      border-radius: 12px;
      background: linear-gradient(135deg, #e53935, #c62828);
      color: #ffffff !important;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 7px;
      font-weight: 800;
      font-size: 13.5px;
      box-shadow: 0 4px 14px rgba(198, 40, 40, 0.28);
      text-decoration: none;
      transition: all 0.25s ease;
    }

    .mobile-action-donate:hover {
      transform: translateY(-1px);
      box-shadow: 0 6px 18px rgba(198, 40, 40, 0.38);
    }

    .mobile-action-auth {
      flex: 1;
      height: 42px;
      border-radius: 12px;
      background: linear-gradient(135deg, #008f8a, #00736f);
      color: #ffffff !important;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 7px;
      font-weight: 700;
      font-size: 13.5px;
      box-shadow: 0 4px 14px rgba(0, 143, 138, 0.28);
      text-decoration: none;
      transition: all 0.25s ease;
    }

    .mobile-action-auth:hover {
      transform: translateY(-1px);
      box-shadow: 0 6px 18px rgba(0, 143, 138, 0.38);
    }

    /* Drawer Navigation Body */
    .mobile-menu-container {
      flex: 1;
      overflow-y: auto;
      padding: 10px 14px 20px 14px;
      scrollbar-width: thin;
      scrollbar-color: rgba(0, 0, 0, 0.15) transparent;
    }

    .mobile-menu-container::-webkit-scrollbar {
      width: 4px;
    }

    .mobile-menu-container::-webkit-scrollbar-thumb {
      background: rgba(0, 0, 0, 0.15);
      border-radius: 4px;
    }

    .mobile-menu {
      list-style: none;
      padding: 0;
      margin: 0;
      display: flex;
      flex-direction: column;
      gap: 4px;
    }

    .mobile-menu > li {
      width: 100%;
      border-radius: 12px;
      transition: background 0.2s ease;
    }

    .mobile-menu a,
    .mobile-menu > li > a,
    .mobile-menu li a {
      display: flex !important;
      align-items: center !important;
      justify-content: space-between !important;
      padding: 12px 14px !important;
      color: #1e293b !important;
      text-decoration: none !important;
      font-size: 14.5px !important;
      font-weight: 700 !important;
      border-radius: 10px !important;
      transition: all 0.2s ease !important;
    }

    .mobile-menu > li > a:hover {
      background: rgba(250, 166, 26, 0.12) !important;
      color: #008f8a !important;
    }

    .mobile-menu > li > a:active {
      background: rgba(250, 166, 26, 0.18) !important;
    }

    /* Highlighted / Special Menu item */
    .mobile-menu .highlighted-menu > a {
      background: rgba(250, 166, 26, 0.15);
      color: #d97706;
      font-weight: 800;
    }

    /* Mega Menu Accordion in Mobile Drawer */
    .mobile-menu .mega-menu-content {
      display: none;
      position: static;
      background: rgba(248, 250, 252, 0.85);
      border: 1px solid rgba(0, 0, 0, 0.06);
      border-radius: 12px;
      margin: 4px 0 8px 0;
      padding: 14px 16px;
      opacity: 1 !important;
      visibility: visible !important;
      transform: none !important;
      transition: none !important;
      box-shadow: inset 0 2px 6px rgba(0, 0, 0, 0.02);
    }

    .mobile-menu .mega-menu-content.active {
      display: block;
      animation: mobileSubMenuFade 0.25s ease forwards;
    }

    @keyframes mobileSubMenuFade {
      from { opacity: 0; transform: translateY(-6px); }
      to { opacity: 1; transform: translateY(0); }
    }

    .mobile-menu .mega-row {
      display: flex;
      flex-direction: column;
      gap: 12px;
    }

    .mobile-menu .mega-col {
      border: none;
      padding: 0;
    }

    .mobile-menu .mega-col h6,
    .mobile-menu .mega-col .mega-col-title {
      color: #008f8a;
      font-size: 13px;
      font-weight: 800;
      margin: 10px 0 6px 0;
      padding-bottom: 4px;
      border-bottom: 1px dashed rgba(0, 143, 138, 0.2);
    }

    .mobile-menu .mega-col:first-child h6,
    .mobile-menu .mega-col:first-child .mega-col-title {
      margin-top: 0;
    }

    .mobile-menu .mega-col a {
      font-size: 13.5px;
      font-weight: 600;
      padding: 8px 10px;
      color: #475569;
      display: block;
      border-radius: 8px;
      text-decoration: none;
      transition: all 0.2s ease;
      margin-bottom: 2px;
    }

    .mobile-menu .mega-col a:hover {
      background: #ffffff;
      color: #faa61a;
      padding-right: 14px;
      box-shadow: 0 2px 6px rgba(0, 0, 0, 0.04);
    }

    /* Accordion Toggle Indicator */
    .mobile-menu .mega-toggle {
      position: relative;
      display: flex !important;
      align-items: center;
      justify-content: space-between;
    }

    .mobile-menu .mega-toggle::after {
      content: "▾";
      font-size: 16px;
      transition: transform 0.3s ease;
    }

    .mobile-menu .mega-toggle.open::after {
      transform: rotate(180deg);
    }

    /* ===== SUB MENU ===== */
    /* مخفی کردن سایدبار در حالت عادی (دسکتاپ) */
    .mobile-menu-sidebar {
      display: block; /* برای اینکه CSS های داخلیش لود بشه */
      right: -320px;
    }

    /* فقط وقتی که کلاس open دارد، در موبایل نمایش داده شود */
    @media (max-width: 1399px) {
      .mobile-menu-sidebar.open {
        right: 0;
      }
    }

    /* جلوگیری از اسکرول خوردن دسکتاپ بخاطر سایدبار */
    @media (min-width: 1025px) {
      .mobile-menu-sidebar { display: none !important; }
    }

    .toggle-sub{
      cursor: pointer;
      position: relative;
    }

    .toggle-sub::after{
      content: "▾";
      position: absolute;
      left: 0;
      transition: .3s;
    }

    .sub-menu.active ~ .toggle-sub::after{
      transform: rotate(180deg);
    }

    /* ===== BACKDROP ===== */
    .mobile-backdrop{
      position: fixed;
      inset: 0;
      background: rgba(0,0,0,.45);
      z-index: 199999;
      opacity: 0;
      pointer-events: none;
      transition: .3s;
    }

    .mobile-backdrop.show{
      opacity: 1;
      pointer-events: auto;
    }

    /* ===== Responsive ===== */
    html, body {
      margin: 0;            /* حذفِ حاشیه‌ی پیش‌فرضِ مرورگر (۸px) که دورِ کلِ صفحه می‌افتاد */
      padding: 0;
      overflow-x: hidden;
      max-width: 100%;
    }

    * {
      box-sizing: border-box;
    }

    /* تنظیمات تبلت و دسکتاپ متوسط */
    @media (max-width: 1200px) {
      .cta-menu { gap: 4px; }
      .cta-menu > li > a { padding: 8px 7px; font-size: 13px; }
    }

    /* نقطه شکست موبایل و تبلت برای سایدبار همبرگری */
    @media (max-width: 1399px) {
      :root {
        --cta-nav-h: 56px;
      }

      .cta-center {
        display: none !important;
      }

      .menu-icon {
        display: flex;
        order: 3;
        position: relative;
        z-index: 1000;
      }

      .cta-left {
        max-width: 100%;
        flex: 1 1 auto;
        justify-content: flex-end;
        gap: 10px;
      }

      .cta-donate {
        display: none;
      }

      .cta-auth {
        order: 2;
        font-size: 13px;
        padding: 0 12px;
        height: 36px;
      }

      #mobileMenu {
        display: block;
      }

      #mobileBackdrop {
        display: block;
      }
    }

    /* غیرفعال‌سازی سایدبار و بک‌دراپ در دسکتاپ بزرگ */
    @media (min-width: 1025px) {
      .mobile-menu-sidebar {
        display: none !important;
      }
      .mobile-backdrop {
        display: none !important;
      }
    }

    /* تبلت های کوچک */
    @media (max-width: 600px) {
      .cta-header {
        padding: 0 12px;
        gap: 8px;
      }

      .cta-right {
        flex-shrink: 0;
        padding-left: 20px;
        padding-right: calc(var(--cta-edge-gap) + 6px);
      }

      .cta-glass-underlay {
        clip-path: polygon(20px 0, 100% 0, 100% 100%, 0 100%);
      }

      .cta-glass-underlay::before {
        width: 30px;
        clip-path: polygon(20px 0, 30px 0, 10px 100%, 0 100%);
      }

      .cta-glass-underlay::after {
        width: 22px;
        clip-path: polygon(18.5px 0, 20px 0, 1.5px 100%, 0 100%);
      }

      .cta-brand img {
        height: 28px;
      }

      .cta-left {
        gap: 8px;
      }

      .cta-donate,
      .cta-auth {
        padding: 0 10px;
        font-size: 12px;
        height: 32px;
      }

      .menu-icon {
        width: 34px;
        height: 34px;
      }
    }

    /* گوشی‌های بسیار باریک */
    @media (max-width: 420px) {
      .cta-header {
        padding: 0 8px;
        gap: 6px;
      }

      .cta-right {
        padding-left: 14px;
        padding-right: calc(var(--cta-edge-gap) + 4px);
      }

      .cta-glass-underlay {
        clip-path: polygon(15px 0, 100% 0, 100% 100%, 0 100%);
      }

      .cta-glass-underlay::before {
        width: 22px;
        clip-path: polygon(15px 0, 22px 0, 7px 100%, 0 100%);
      }

      .cta-glass-underlay::after {
        width: 17px;
        clip-path: polygon(13.5px 0, 15px 0, 1.5px 100%, 0 100%);
      }

      .cta-brand img {
        height: 24px;
      }

      .cta-donate,
      .cta-auth {
        padding: 0 8px;
        font-size: 11px;
        height: 30px;
        gap: 4px;
      }

      .menu-icon {
        width: 32px;
        height: 32px;
      }

      .menu-icon div {
        width: 15px;
      }
    }

    /* ===== Account widget (logged-in state) ===== */
    .cta-auth-slot{position:relative;display:inline-flex;align-items:center}
    .cta-account{position:relative}
    .cta-account-btn{
      height:38px;border-radius:10px;border:1px solid rgba(0, 143, 138,.4);
      background:linear-gradient(135deg, #008f8a, #00736f);color:#fff;
      padding:0 12px;cursor:pointer;display:inline-flex;align-items:center;gap:8px;
      white-space:nowrap;font-weight:700;box-shadow:0 0 12px rgba(0, 143, 138,.3);
      transition:all .3s cubic-bezier(.16,1,.3,1);
    }
    .cta-account-btn:hover{transform:translateY(-2px);box-shadow:0 0 20px rgba(0, 143, 138,.6);background:linear-gradient(135deg, #05a8a2, #008f8a)}
    .cta-account-btn:active{transform:translateY(1px)}
    .cta-account-avatar{width:26px;height:26px;border-radius:50%;background:rgba(255,255,255,.18);
      display:grid;place-items:center;font-weight:800;font-size:13px;overflow:hidden;flex-shrink:0;color:#fff}
    .cta-account-avatar img{width:100%;height:100%;object-fit:cover;border-radius:50%}
    .cta-account-avatar svg{width:16px;height:16px}
    .cta-account-name{max-width:120px;overflow:hidden;text-overflow:ellipsis;font-size:13px}
    .cta-account-caret{width:14px;height:14px;transition:transform .25s ease;opacity:.85;flex-shrink:0}
    .cta-account.open .cta-account-caret{transform:rotate(180deg)}
    .cta-account-menu{
      position:absolute;top:calc(100% + 10px);left:0;min-width:236px;
      background:rgba(15,23,42,.94);backdrop-filter:blur(16px) saturate(160%);
      -webkit-backdrop-filter:blur(16px) saturate(160%);
      border:1px solid rgba(255,255,255,.12);border-radius:14px;
      box-shadow:0 20px 40px rgba(0,0,0,.45);padding:8px;
      opacity:0;visibility:hidden;transform:translateY(-8px) scale(.98);transform-origin:top left;
      transition:opacity .2s,transform .22s cubic-bezier(.16,1,.3,1),visibility .2s;
      z-index:100001;direction:rtl;text-align:right;
      max-width: calc(100vw - 20px);
    }

    @media (max-width: 480px) {
      .cta-account-menu {
        min-width: auto;
        right: 10px;
        left: auto;
        transform-origin: top right;
      }
    }
    .cta-account.open .cta-account-menu{opacity:1;visibility:visible;transform:translateY(0) scale(1)}
    .cta-account-head{display:flex;align-items:center;gap:10px;padding:8px 8px 12px;
      border-bottom:1px solid rgba(255,255,255,.1);margin-bottom:6px}
    .cta-account-head .cta-account-avatar{width:42px;height:42px;font-size:16px}
    .cta-account-head strong{display:block;color:#fff;font-size:13.5px;font-weight:800;
      max-width:160px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
    .cta-account-head span{display:block;color:rgba(255,255,255,.6);font-size:11.5px;
      max-width:160px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;direction:ltr;text-align:right}
    .cta-account-menu a,.cta-account-menu button{
      display:flex;align-items:center;gap:10px;width:100%;text-align:right;
      padding:10px 12px;border-radius:10px;color:rgba(255,255,255,.9);font-size:13px;font-weight:600;
      background:none;border:none;cursor:pointer;transition:background .18s,color .18s;font-family:inherit;text-decoration:none;
    }
    .cta-account-menu a:hover,.cta-account-menu button:hover{background:rgba(255,255,255,.1);color:#fff}
    .cta-account-menu svg{width:17px;height:17px;opacity:.85;flex-shrink:0}
    .cta-account-logout{color:#ffb4b4 !important;margin-top:6px;border-top:1px solid rgba(255,255,255,.1) !important;border-radius:0 0 8px 8px !important}
    .cta-account-logout:hover{background:rgba(229,57,53,.28) !important;color:#fff !important}
    [hidden]{display:none !important}
  </style>

<?php 
require_once __DIR__ . '/../../../event-lib.php'; 
require_once __DIR__ . '/../../../event-banner.php'; 
echo event_global_banner(isset($pdo) && $pdo instanceof PDO ? $pdo : null); 
?>

  <div class="cta" dir="rtl">

    <div class="cta-topbar">
      <div class="cta-container cta-header">

        <div class="cta-right">
          <div class="cta-glass-underlay" aria-hidden="true"></div>
          <a class="cta-brand" href="/home">
            <img src="/dashboard/components/header/images/1.png" alt="مکسا - مؤسسه نیکوکاری کنترل سرطان" width="182" height="52" decoding="async">
          </a>
        </div>

        <!-- منوی افقی + مگا منو -->
        <div class="cta-center">
          <nav class="cta-navbox" aria-label="منوی بالا">
            <ul class="cta-menu" id="menu">

              <li>
                <a href="/home">خانه</a>
              </li>

              <li class="mega-menu">
                <a class="mega-toggle" href="/history">آشنایی با مکسا</a>
                <div class="mega-menu-content">
                  <div class="mega-row">
                    <div class="mega-col">
                      <div class="mega-col-title">معرفی</div>
                      <a href="/history">تاریخچه و نحوه تاسیس</a>
                      <a href="/mission-vision">ماموریت و چشم انداز</a>
                      <a href="/association">اساسنامه</a>
                      <a href="/organizationalchart">چارت سازمانی</a>
                      <a href="/headdirectors">شورای عالی</a>
                      <a href="/directors">هیئت مدیره</a>
                      <a href="/CEOoffice">مدیرعامل</a>
                      <a href="/network.php">شبکه همکاران</a>
                    </div>
                    <div class="mega-col">
                      <div class="mega-col-title">مراکز تابعه مکسا</div>
                      <a href="/cdst">مرکز رویش استعدادهای دانشجویی مکسا</a>
                      <a href="/amoozesh_maharati.html">مرکز آموزش مهارتی مکسا</a>
                    </div>
                    <div class="mega-col">
                      <div class="mega-col-title">گزارش‌ها</div>
                      <a href="/image-gallery.html">گزارش‌های سالانه</a>
                      <a href="/video-gallery.html">صورت‌های مالی</a>
                    </div>
                  </div>
                </div>
              </li>

              <li class="mega-menu">
                <a class="mega-toggle" href="/supportiveandpalliativecare">خدمات مکسا</a>
                <div class="mega-menu-content">
                  <div class="mega-row">
                    <div class="mega-col">
                      <div class="mega-col-title">مراقبت های حمایتی و تسکینی</div>
                      <a href="/supportiveandpalliativecare">مفهوم مراقبت های حمایتی و تسکینی</a>
                      <a href="/supportiveandpalliativecareteam">اعضای تیم حمایتی و تسکینی</a>
                      <a href="/endoflifecare">مراقبت‌های پایان زندگی</a>
                      <a href="/iran-situation-in-palliative">وضعیت مراقبت های حمایتی و تسکینی در ایران</a>
                      <a href="/doctorspage">نقش کادر درمان</a>
                    </div>
                    <div class="mega-col">
                      <div class="mega-col-title">مراقبت های حمایتی و تسکینی</div>
                      <a href="/medicalcare">مراقبت های پزشکی تسکینی</a>
                      <a href="/nursecare">مراقبت های پرستاری تسکینی</a>
                      <a href="/psychologicalcare">مراقبت های روانشناختی</a>
                      <a href="/socialworkcare">مددکاری اجتماعی</a>
                      <a href="/spritualcare">مراقبت های معنوی</a>
                      <a href="/nutritioncare">مراقبت های تغذیه</a>
                      <a href="/physiotherapycare">مراقبت های بازتوانی و توانبخشی</a>
                      <a href="/geneticconseuling">مشاوره ژنتیک و غربالگری</a>
                      <a href="/medicalequipments">تامین تجهیزات پزشکی</a>
                    </div>
                    <div class="mega-col">
                      <div class="mega-col-title">بخش‌ها</div>
                      <a href="/supportiveandpalliativecare">مراقبت در منزل</a>
                      <a href="/MACSAservices.html">بستری</a>
                      <a href="/MACSAservices.html">سرپایی</a>
                      <a href="/MACSAservices.html">کلینیک</a>
                    </div>
                    <div class="mega-col">
                      <div class="mega-col-title">پذیرش بیمار</div>
                      <a href="/patientintake">نوبت دهی</a>
                      <a href="/patientintake">مدارک موردنیاز</a>
                    </div>
                  </div>
                </div>
              </li>

              <li class="mega-menu">
                <a class="mega-toggle" href="/single-fundraising-option">روش های حمایت</a>
                <div class="mega-menu-content">
                  <div class="mega-row">
                    <div class="mega-col">
                      <div class="mega-col-title">همیاری مالی</div>
                      <a href="/onlinedonation">حمایت مالی آنلاین</a>
                      <a href="/under-construction.html">پرداخت مستمر هدایای نقدی</a>
                    </div>
                    <div class="mega-col">
                      <div class="mega-col-title">همیاری اجتماعی و فرهنگی</div>
                      <a href="/under-construction.html">مسئولیت اجتماعی</a>
                      <a href="/under-construction.html">حمایت های خلاقانه و هنری</a>
                    </div>
                    <div class="mega-col">
                      <div class="mega-col-title">همیاری علمی و تخصصی</div>
                      <a href="/under-construction.html">حمایت علمی و تخصصی</a>
                      <a href="/under-construction.html">اهدای تجهیزات پزشکی</a>
                    </div>
                    <div class="mega-col">
                      <div class="mega-col-title">مشارکت داوطلبی</div>
                      <a href="/under-construction.html">همکاری داوطلبانه</a>
                      <a href="/under-construction.html">شرایط جذب داوطلبان</a>
                    </div>
                  </div>
                </div>
              </li>

              <li><a href="/branches.php">شعب</a></li>
              <li><a href="/news.php">اخبار</a></li>
              <li class="events-nav-link"><a href="/events.php">رویدادها و همایش‌ها</a></li>
              <li><a href="/macsapedia.php">مکساپدیا</a></li>
              <li><a href="/courses">دوره‌ها</a></li>
              <li><a href="/contactus">تماس با ما</a></li>
            </ul>
          </nav>
        </div>

        <div class="cta-left">
          <div class="menu-icon" id="menuToggle" aria-label="منوی موبایل">
            <div></div>
            <div></div>
            <div></div>
          </div>

          <a class="cta-donate" href="/onlinedonation" aria-label="کمک آنلاین">
            کمک آنلاین
          </a>

          <div class="cta-auth-slot">
            <a class="cta-auth js-cta-login" href="/benefactor-dashboard/" aria-label="ورود یا ثبت نام">
              ورود / ثبت‌نام
            </a>

            <div class="cta-account js-cta-account" hidden>
              <button class="cta-account-btn" type="button" aria-haspopup="true" aria-expanded="false" aria-label="حساب کاربری">
                <span class="cta-account-avatar js-acc-avatar">
                  <svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M12 12a4 4 0 1 0-4-4 4 4 0 0 0 4 4z" stroke="currentColor" stroke-width="2"/><path d="M4 20c1.2-3.5 4.2-5.5 8-5.5s6.8 2 8 5.5" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>
                </span>
                <span class="cta-account-name js-acc-name">حساب کاربری</span>
                <svg class="cta-account-caret" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M6 9l6 6 6-6" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>
              </button>

              <div class="cta-account-menu" role="menu">
                <div class="cta-account-head">
                  <span class="cta-account-avatar js-acc-avatar-lg">
                    <svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M12 12a4 4 0 1 0-4-4 4 4 0 0 0 4 4z" stroke="currentColor" stroke-width="2"/><path d="M4 20c1.2-3.5 4.2-5.5 8-5.5s6.8 2 8 5.5" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>
                  </span>
                  <div>
                    <strong class="js-acc-fullname">کاربر مکسا</strong>
                    <span class="js-acc-email"></span>
                  </div>
                </div>

                <a role="menuitem" href="/benefactor-dashboard/">
                  <svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><rect x="3" y="3" width="7" height="9" rx="1.5" stroke="currentColor" stroke-width="2"/><rect x="14" y="3" width="7" height="5" rx="1.5" stroke="currentColor" stroke-width="2"/><rect x="14" y="12" width="7" height="9" rx="1.5" stroke="currentColor" stroke-width="2"/><rect x="3" y="16" width="7" height="5" rx="1.5" stroke="currentColor" stroke-width="2"/></svg>
                  داشبورد من
                </a>
                <a role="menuitem" href="/benefactor-dashboard/profile">
                  <svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M12 12a4 4 0 1 0-4-4 4 4 0 0 0 4 4z" stroke="currentColor" stroke-width="2"/><path d="M4 20c1.2-3.5 4.2-5.5 8-5.5s6.8 2 8 5.5" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>
                  پروفایل کاربری
                </a>
                <a role="menuitem" href="/benefactor-dashboard/history">
                  <svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><rect x="3" y="5" width="18" height="14" rx="2" stroke="currentColor" stroke-width="2"/><path d="M3 10h18" stroke="currentColor" stroke-width="2"/></svg>
                  پرداخت‌های من
                </a>
                <a role="menuitem" href="/onlinedonation">
                  <svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M12 21C12 21 4 14.5 4 9.5C4 7 6 5 8.5 5C10.2 5 11.4 5.9 12 7C12.6 5.9 13.8 5 15.5 5C18 5 20 7 20 9.5C20 14.5 12 21 12 21Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
                  کمک آنلاین
                </a>

                <button type="button" class="cta-account-logout js-cta-logout" role="menuitem">
                  <svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M15 4h3a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2h-3" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><path d="M10 17l-5-5 5-5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><path d="M15 12H5" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>
                  خروج از حساب
                </button>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>

  </div>

  <!-- فاصله‌گذار برای جبران ارتفاع نوار ثابت بالا -->
  <div class="cta-navbar-spacer" aria-hidden="true"></div>

  <nav class="mobile-menu-sidebar" id="mobileMenu" dir="rtl" aria-label="منوی موبایل">
    <div class="mobile-menu-header">
      <div class="mobile-menu-brand">
        <img src="/dashboard/components/header/images/1.png" alt="مکسا - مؤسسه نیکوکاری کنترل سرطان" width="182" height="52" loading="lazy" decoding="async">
      </div>
      <button type="button" class="mobile-menu-close" id="mobileMenuClose" aria-label="بستن منو">
        <svg viewBox="0 0 24 24" fill="none" width="18" height="18">
          <path d="M18 6L6 18M6 6l12 12" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
      </button>
    </div>

    <div class="mobile-menu-actions">
      <a class="mobile-action-donate" href="/onlinedonation">
        <svg viewBox="0 0 24 24" fill="none" width="17" height="17"><path d="M12 21C12 21 4 14.5 4 9.5C4 7 6 5 8.5 5C10.2 5 11.4 5.9 12 7C12.6 5.9 13.8 5 15.5 5C18 5 20 7 20 9.5C20 14.5 12 21 12 21Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
        کمک آنلاین
      </a>
      <a class="mobile-action-auth js-mobile-login" href="/benefactor-dashboard/">
        <svg viewBox="0 0 24 24" fill="none" width="17" height="17"><path d="M12 12a4 4 0 1 0-4-4 4 4 0 0 0 4 4z" stroke="currentColor" stroke-width="2"/><path d="M4 20c1.2-3.5 4.2-5.5 8-5.5s6.8 2 8 5.5" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>
        ورود / ثبت‌نام
      </a>
    </div>

    <div class="mobile-menu-container" id="mobileMenuContainer"></div>

    <div class="mobile-menu-footer">
      <div class="mobile-footer-info">
        <svg viewBox="0 0 24 24" fill="none" width="16" height="16"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z" stroke="currentColor" stroke-width="2"/></svg>
        <span>پشتیبانی: <a href="tel:02191092030" dir="ltr" style="display:inline-block; font-family:inherit; color:inherit; text-decoration:none; unicode-bidi:isolate;">021-91092030</a></span>
      </div>
      <div class="mobile-footer-tagline">مؤسسه نیکوکاری کنترل سرطان ایرانیان (مکسا)</div>
    </div>
  </nav>
  <div class="mobile-backdrop" id="mobileBackdrop"></div>

  <script>
  (function(){
    const toggleBtn = document.getElementById("menuToggle");
    const closeBtn = document.getElementById("mobileMenuClose");
    const menu = document.getElementById("mobileMenu");
    const backdrop = document.getElementById("mobileBackdrop");

    if(!toggleBtn || !menu) return;

    function openMenu(){
      menu.classList.add("open");
      if(backdrop) backdrop.classList.add("show");
      toggleBtn.classList.add("active");
      document.body.classList.add("mobile-menu-open");
    }

    function closeMenu(){
      menu.classList.remove("open");
      if(backdrop) backdrop.classList.remove("show");
      toggleBtn.classList.remove("active");
      document.body.classList.remove("mobile-menu-open");
    }

    toggleBtn.addEventListener("click", function(e){
      e.stopPropagation();
      menu.classList.contains("open") ? closeMenu() : openMenu();
    });

    if(closeBtn) closeBtn.addEventListener("click", closeMenu);
    if(backdrop) backdrop.addEventListener("click", closeMenu);

    document.querySelectorAll(".toggle-sub").forEach(function(btn){
      btn.addEventListener("click", function(){
        const sub = btn.nextElementSibling;
        if(sub) sub.classList.toggle("active");
      });
    });

    // مگا منو دسکتاپ: باز/بسته شدن با هاور
    (function () {
      const DELAY = 200; // مدت ماندگاری (ms)
      const menus = document.querySelectorAll(".mega-menu");

      menus.forEach(function (menu) {
        let closeTimer = null;

        function openMenu() {
          if (closeTimer) {
            clearTimeout(closeTimer);
            closeTimer = null;
          }

          // بستن فوری بقیه مگا منوها بدون تاخیر
          menus.forEach(function (other) {
            if (other !== menu) {
              if (other.__closeTimer__) {
                clearTimeout(other.__closeTimer__);
                other.__closeTimer__ = null;
              }
              other.classList.remove("open");
            }
          });

          menu.classList.add("open");
        }

        function closeMenu() {
          if (closeTimer) clearTimeout(closeTimer);

          closeTimer = setTimeout(function () {
            menu.classList.remove("open");
            closeTimer = null;
            menu.__closeTimer__ = null;
          }, DELAY);

          menu.__closeTimer__ = closeTimer;
        }

        const toggle = menu.querySelector(".mega-toggle");
        const content = menu.querySelector(".mega-menu-content");

        if (toggle) {
          toggle.addEventListener("mouseenter", openMenu);
          toggle.addEventListener("mouseleave", closeMenu);
        }

        if (content) {
          content.addEventListener("mouseenter", openMenu);
          content.addEventListener("mouseleave", closeMenu);
        }
      });
    })();

    document.addEventListener("DOMContentLoaded", function(){
      const desktopMenu = document.querySelector(".cta-menu");
      const container = document.getElementById("mobileMenuContainer");

      if(!desktopMenu || !container) return;

      // کپی کامل منو در کانتینر مخصوص اسکرول سایدبار
      const clonedMenu = desktopMenu.cloneNode(true);
      clonedMenu.classList.remove("cta-menu");
      clonedMenu.classList.add("mobile-menu");
      container.appendChild(clonedMenu);

      // تبدیل مگا منو به آکاردئون
      container.querySelectorAll(".mega-menu").forEach(function(item){
        const toggle = item.querySelector(".mega-toggle");
        const content = item.querySelector(".mega-menu-content");

        if(toggle && content){
          toggle.addEventListener("click", function(e){
            e.preventDefault();
            content.classList.toggle("active");
            toggle.classList.toggle("open");
          });
        }
      });

      // هدر همیشه ثابت و قابل مشاهده؛ فقط ظاهر «جداشده» هنگام اسکرول
      (function() {
        const topbar = document.querySelector(".cta-topbar");
        if (!topbar) return;

        window.addEventListener("scroll", function() {
          // اگر اسکرول بیشتر از 50 پیکسل بود هدر جدا شود (بدون مخفی شدن)
          if (window.scrollY > 50) {
            topbar.classList.add("scrolled");
          } else {
            topbar.classList.remove("scrolled");
          }
        });
      })();
    });
  })();
  </script>

  <!-- ===== وضعیت ورود کاربر: تبدیل دکمه «ورود/ثبت‌نام» به منوی حساب کاربری ===== -->
  <script>
  (function(){
    if (window.__ctaAuthWidget__) return;   // فقط یک‌بار اجرا شود حتی اگر چند کامپوننت نوار در صفحه باشد
    window.__ctaAuthWidget__ = true;

    function ready(fn){
      if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', fn);
      else fn();
    }
    function initials(u){
      var f=(u.first_name||'').trim(), l=(u.last_name||'').trim();
      if(f||l) return ((f[0]||'')+(l[0]||'')) || (f[0]||l[0]||'');
      var e=(u.email||'').trim();
      return e ? e[0].toUpperCase() : '؟';
    }
    function displayName(u){
      var n=((u.first_name||'')+' '+(u.last_name||'')).trim();
      if(n) return n;
      return u.email ? u.email.split('@')[0] : 'حساب کاربری';
    }
    function setAvatar(el, u){
      if(!el) return;
      if(u.avatar_url){
        el.innerHTML='';
        var img=document.createElement('img'); img.src=u.avatar_url; img.alt=''; el.appendChild(img);
      } else {
        el.textContent = initials(u);
      }
    }
    function renderLoggedIn(slot, u){
      var login = slot.querySelector('.js-cta-login');
      var account = slot.querySelector('.js-cta-account');
      if(login) login.setAttribute('hidden','');

      var mobLogin = document.querySelector('.js-mobile-login');
      if(mobLogin){
        mobLogin.href = '/benefactor-dashboard/';
        mobLogin.innerHTML = '<svg viewBox="0 0 24 24" fill="none" width="17" height="17"><rect x="3" y="3" width="7" height="9" rx="1.5" stroke="currentColor" stroke-width="2"/><rect x="14" y="3" width="7" height="5" rx="1.5" stroke="currentColor" stroke-width="2"/><rect x="14" y="12" width="7" height="9" rx="1.5" stroke="currentColor" stroke-width="2"/><rect x="3" y="16" width="7" height="5" rx="1.5" stroke="currentColor" stroke-width="2"/></svg> داشبورد من';
      }

      if(!account) return;
      account.removeAttribute('hidden');

      var name = displayName(u);
      var nameEl = slot.querySelector('.js-acc-name'); if(nameEl) nameEl.textContent = name;
      var fullEl = slot.querySelector('.js-acc-fullname'); if(fullEl) fullEl.textContent = name;
      var emailEl = slot.querySelector('.js-acc-email'); if(emailEl) emailEl.textContent = u.email || '';
      setAvatar(slot.querySelector('.js-acc-avatar'), u);
      setAvatar(slot.querySelector('.js-acc-avatar-lg'), u);

      var btn = slot.querySelector('.cta-account-btn');
      if(btn){
        btn.addEventListener('click', function(e){
          e.stopPropagation();
          var open = account.classList.toggle('open');
          btn.setAttribute('aria-expanded', open ? 'true' : 'false');
        });
      }
      var menu = slot.querySelector('.cta-account-menu');
      if(menu){ menu.addEventListener('click', function(e){ e.stopPropagation(); }); }

      var logout = slot.querySelector('.js-cta-logout');
      if(logout){
        logout.addEventListener('click', function(){
          logout.disabled = true;
          fetch('/api/auth/logout', { method:'POST', credentials:'include' })
            .catch(function(){})
            .then(function(){ window.location.reload(); });
        });
      }
    }

    // کلیک بیرون / Escape همه‌ی منوهای باز را می‌بندد
    document.addEventListener('click', function(){
      document.querySelectorAll('.cta-account.open').forEach(function(a){
        a.classList.remove('open');
        var b=a.querySelector('.cta-account-btn'); if(b) b.setAttribute('aria-expanded','false');
      });
    });
    document.addEventListener('keydown', function(e){
      if(e.key === 'Escape'){
        document.querySelectorAll('.cta-account.open').forEach(function(a){
          a.classList.remove('open');
          var b=a.querySelector('.cta-account-btn'); if(b) b.setAttribute('aria-expanded','false');
        });
      }
    });

    ready(function(){
      var slots = Array.prototype.slice.call(document.querySelectorAll('.cta-auth-slot'));
      if(!slots.length) return;

      // فقط در صورتی که نشانه لاگین وجود داشته باشد تلاش برای رفرش انجام می‌شود تا خطای ۴۰۱ برای مهمان در کنسول ثبت نشود
      var hasSession = document.cookie.indexOf('maksa_session=1') !== -1 ||
                       localStorage.getItem('maksa_logged') === '1' ||
                       sessionStorage.getItem('maxa_access_token');
      if(!hasSession) return;

      // با کوکی رفرش (httpOnly) یک access_token تازه می‌گیریم؛ این کار نشست را هم تمدید می‌کند.
      fetch('/api/auth/refresh', { method:'POST', credentials:'include', headers:{ 'Accept':'application/json' } })
        .then(function(res){
          if(!res.ok){
            try {
              localStorage.removeItem('maksa_logged');
              sessionStorage.removeItem('maxa_access_token');
            } catch(e) {}
            return null;
          }
          return res.json();
        })
        .then(function(j){
          var token = j && j.data && j.data.access_token;
          if(!token) return null;
          try {
            window.__maxa_access_token = token;
            sessionStorage.setItem('maxa_access_token', token);
          } catch(e) {}
          return fetch('/api/user/me', {
            headers:{ 'Authorization':'Bearer '+token, 'Accept':'application/json' },
            credentials:'include'
          })
          .then(function(r){ return r.ok ? r.json() : null; })
          .then(function(me){ return (me && me.data && me.data.user) ? me.data.user : {}; });
        })
        .then(function(user){
          if(!user) return;   // وارد نشده: همان دکمه ورود/ثبت‌نام بماند
          slots.forEach(function(slot){ renderLoggedIn(slot, user); });
        })
        .catch(function(){ /* وارد نشده */ });
    });
  })();
  </script>


